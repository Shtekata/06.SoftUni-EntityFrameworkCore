﻿namespace P03_FootballBetting.Data.Configurations
{
    internal static class Configuration
    {
        internal static string ConfigurationString = @"server=.\sqlexpress;database=FootballBetting;integrated security=true";
    }
}
