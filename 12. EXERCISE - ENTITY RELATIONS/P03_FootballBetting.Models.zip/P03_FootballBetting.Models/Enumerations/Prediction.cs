﻿namespace P03_FootballBetting.Data.Models.Enumerations
{
    public enum Prediction
    {
        Win=1,
        Draw=0,
        Lost=-1
    }
}
