﻿using Microsoft.EntityFrameworkCore;
using P03_FootballBetting.Data.Configurations;
using P03_FootballBetting.Data.Models;

namespace P03_FootballBetting.Data
{
    public class FootballBettingContext : DbContext
    {
        public FootballBettingContext()
        {
        }
        public FootballBettingContext(DbContextOptions options)
            : base(options)
        {
        }
        public DbSet<Team> Teams { get; set; }
        public DbSet<Color> Colors { get; set; }
        public DbSet<Town> Towns { get; set; }
        public DbSet<Country> Countries { get; set; }
        public DbSet<Player> Players { get; set; }
        public DbSet<Position> Positions { get; set; }
        public DbSet<PlayerStatistic> PlayerStatistics { get; set; }
        public DbSet<Game> Games { get; set; }
        public DbSet<Bet> Bets { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(Configuration.ConfigurationString);
            }
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Team>(x =>
            {
                x.HasKey(y => y.TeamId);
                x.Property(y => y.Name).HasMaxLength(50).IsRequired().IsUnicode();
                x.Property(y => y.LogoUrl).HasMaxLength(250).IsRequired(false).IsUnicode(false);
                x.Property(y => y.Initials).HasMaxLength(3).IsRequired().IsUnicode();
                x.Property(y => y.Budget).IsRequired();
                x.HasOne(y => y.PrimaryKitColor).WithMany(y => y.PrimaryKitTeams).HasForeignKey(y => y.PrimaryKitColorId).OnDelete(DeleteBehavior.Restrict);
                x.HasOne(y => y.SecondaryKitColor).WithMany(y => y.SecondaryKitTeams).HasForeignKey(y => y.SecondaryKitColorId).OnDelete(DeleteBehavior.Restrict);
                x.HasOne(y => y.Town).WithMany(y => y.Teams).HasForeignKey(y => y.TownId);
            });
            modelBuilder.Entity<Color>(x =>
            {
                x.HasKey(y => y.ColorId);
                x.Property(y => y.Name).HasMaxLength(30).IsRequired().IsUnicode();
            });
            modelBuilder.Entity<Town>(x =>
            {
                x.HasKey(y => y.TownId);
                x.Property(y => y.Name).HasMaxLength(50).IsRequired().IsUnicode();
                x.HasOne(y => y.Country).WithMany(y => y.Towns).HasForeignKey(y => y.CountryId);
            });
            modelBuilder.Entity<Country>(x =>
            {
                x.HasKey(y => y.CountryId);
                x.Property(y => y.Name).HasMaxLength(50).IsRequired().IsUnicode();
            });
            modelBuilder.Entity<Player>(x =>
            {
                x.HasKey(y => y.PlayerId);
                x.Property(y => y.Name).HasMaxLength(100).IsRequired().IsUnicode();
                x.Property(y => y.SquadNumber).IsRequired();
                x.Property(y => y.IsInjured).IsRequired();
                x.HasOne(y => y.Team).WithMany(y => y.Players).HasForeignKey(y => y.TeamId);
                x.HasOne(y => y.Position).WithMany(y => y.Players).HasForeignKey(y => y.PositionId);
            });
            modelBuilder.Entity<Position>(x =>
            {
                x.HasKey(y => y.PositionId);
                x.Property(y => y.Name).HasMaxLength(20).IsRequired().IsUnicode();
            });
            modelBuilder.Entity<PlayerStatistic>(x =>
            {
                x.HasKey(y => new { y.PlayerId, y.GameId });
                x.Property(y => y.ScoredGoals).IsRequired();
                x.Property(y => y.Assists).IsRequired();
                x.Property(y => y.MinutesPlayed).IsRequired();
                x.HasOne(y => y.Game).WithMany(y => y.PlayerStatistics).HasForeignKey(y => y.GameId);
                x.HasOne(y => y.Player).WithMany(y => y.PlayerStatistics).HasForeignKey(y => y.PlayerId);
            });
            modelBuilder.Entity<Game>(x =>
            {
                x.HasKey(y => y.GameId);
                x.Property(y => y.HomeTeamGoals).IsRequired();
                x.Property(y => y.AwayTeamGoals).IsRequired();
                x.Property(y => y.DateTime).IsRequired();
                x.Property(y => y.HomeTeamBetRate).IsRequired();
                x.Property(y => y.AwayTeamBetRate).IsRequired();
                x.Property(y => y.DrawBetRate).IsRequired();
                x.Property(y => y.Result).HasMaxLength(7).IsRequired().IsUnicode(false);
                x.HasOne(y => y.HomeTeam).WithMany(y => y.HomeGames).HasForeignKey(y => y.HomeTeamId).OnDelete(DeleteBehavior.Restrict);
                x.HasOne(y => y.AwayTeam).WithMany(y => y.AwayGames).HasForeignKey(y => y.AwayTeamId).OnDelete(DeleteBehavior.Restrict);
            });
            modelBuilder.Entity<Bet>(x =>
            {
                x.HasKey(y => y.BetId);
                x.Property(y => y.Amount).IsRequired();
                x.Property(y => y.Prediction).IsRequired();
                x.Property(y => y.DateTime).IsRequired();
                x.HasOne(y => y.User).WithMany(y => y.Bets).HasForeignKey(y => y.UserId);
                x.HasOne(y => y.Game).WithMany(y => y.Bets).HasForeignKey(y => y.GameId);
            });
            modelBuilder.Entity<User>(x =>
            {
                x.HasKey(y => y.UserId);
                x.Property(y => y.Username).HasMaxLength(50).IsRequired().IsUnicode(false);
                x.Property(y => y.Password).HasMaxLength(30).IsRequired().IsUnicode(false);
                x.Property(y => y.Email).HasMaxLength(50).IsRequired().IsUnicode(false);
                x.Property(y => y.Name).HasMaxLength(100).IsRequired(false).IsUnicode();
                x.Property(y => y.Balance).IsRequired();
            });
        }
    }
}
