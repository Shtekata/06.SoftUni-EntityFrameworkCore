﻿namespace P01_HospitalDatabase.Data
{
    static class Configuration
    {
        internal static string ConnectionString= @"Server=.\sqlexpress01;Database=HospitalDatabase;Integrated Security=true";
    }
}
