﻿namespace P03_SalesDatabase.Data
{
    static class Configuration
    {
        internal static string ConnectionString = @"Server=.\sqlexpress01;Database=SalesDatabase;Integrated Security=true";
    }
}
